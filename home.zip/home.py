import streamlit as st

st.set_page_config(page_title="멀티페이지 앱", layout="wide")

st.title("멀티페이지 Streamlit 앱")
st.write("왼쪽 사이드바를 통해 페이지를 선택하세요.")



















